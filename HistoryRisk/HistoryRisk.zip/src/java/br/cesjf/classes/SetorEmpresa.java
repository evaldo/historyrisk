package br.cesjf.classes;

public class SetorEmpresa {
    private int idSetorEmpr;
    private String nmSetorEmpr;
            
    public SetorEmpresa(){
                
    }

    public int getIdSetorEmpr() {
        return idSetorEmpr;
    }

    public void setIdSetorEmpr(int idSetorEmpr) {
        this.idSetorEmpr = idSetorEmpr;
    }

    public String getNmSetorEmpr() {
        return nmSetorEmpr;
    }

    public void setNmSetorEmpr(String nmSetorEmpr) {
        this.nmSetorEmpr = nmSetorEmpr;
    }
    
}
