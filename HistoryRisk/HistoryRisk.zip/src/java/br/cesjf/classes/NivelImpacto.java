package br.cesjf.classes;

public class NivelImpacto {
    
    private int idNivelIpcto;
    private String nmNivelIpcto;
    private String dsNivelIpcto;
    private int icNivelIpcto;

    public NivelImpacto() {
    }

    public int getIdNivelIpcto() {
        return idNivelIpcto;
    }

    public void setIdNivelIpcto(int idNivelIpcto) {
        this.idNivelIpcto = idNivelIpcto;
    }

    public String getNmNivelIpcto() {
        return nmNivelIpcto;
    }

    public void setNmNivelIpcto(String nmNivelIpcto) {
        this.nmNivelIpcto = nmNivelIpcto;
    }

    public String getDsNivelIpcto() {
        return dsNivelIpcto;
    }

    public void setDsNivelIpcto(String dsNivelIpcto) {
        this.dsNivelIpcto = dsNivelIpcto;
    }

    public int getIcNivelIpcto() {
        return icNivelIpcto;
    }

    public void setIcNivelIpcto(int icNivelIpcto) {
        this.icNivelIpcto = icNivelIpcto;
    }

    
    
    
}
