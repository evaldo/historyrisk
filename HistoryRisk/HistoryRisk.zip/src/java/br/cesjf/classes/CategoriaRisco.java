package br.cesjf.classes;

public class CategoriaRisco {

    private int idCategoriaRisco;
    private String dsCategoriaRisco;

    public CategoriaRisco() {
    }

    public int getIdCategoriaRisco() {
        return idCategoriaRisco;
    }

    public void setIdCategoriaRisco(int idCategoriaRisco) {
        this.idCategoriaRisco = idCategoriaRisco;
    }

    public String getDsCategoriaRisco() {
        return dsCategoriaRisco;
    }

    public void setDsCategoriaRisco(String dsCategoriaRisco) {
        this.dsCategoriaRisco = dsCategoriaRisco;
    }
    
    
}
