package br.cesjf.Controller;

import br.cesjf.classes.Projeto;
import br.cesjf.classes.SetorEmpresa;
import br.cesjf.dao.JDBCSetorEmpresaDAO;
import br.cesjf.dao.ProjetoDAO;
import br.cesjf.util.DAOFactory;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ProjetoController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        int idHrskPrjt = Integer.parseInt(request.getParameter("idHrskPrjt"));
        int NumsetorEmpresa = Integer.parseInt(request.getParameter("setorEmpresa"));
        String dsPrjt = request.getParameter("dsPrjt");
        Date dtRgstPrjt = request.getParameter("dtRgstPrjt");
        
       
        Projeto projeto = new Projeto();
        
        projeto.setIdHrskprjt(idHrskPrjt);
        
        JDBCSetorEmpresaDAO ds = new JDBCSetorEmpresaDAO();
        SetorEmpresa setorEmpresa = ds.buscar(rs.getInt(NumsetorEmpresa));
        projeto.setSetorEmpresa(setorEmpresa);
        
        projeto.setSetorEmpresa(setorEmpresa);
        projeto.setDsPrjt(dsPrjt);
        projeto.setDtRgstPrjt(dtRgstPrjt);
        
        
        ProjetoDAO sed = DAOFactory.createProjetoDAO();
        sed.inserir(projeto);
        
        request.getRequestDispatcher("JnlCnsltProjetosp").forward(request,response);
        
    }

}
